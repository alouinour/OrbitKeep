"""Application utilities."""
