"""Request and response schemas."""
